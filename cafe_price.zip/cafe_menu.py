import mysql.connector as p
from prettytable import PrettyTable
mydb=p.connect(host="localhost",user="root",password="Nancymomoland3000@",database="cafe_menu_list")
cur=mydb.cursor()
def main_list():
    cur.execute("show tables")
    show=cur.fetchall()
    head=PrettyTable(['tables'])
    head.add_rows(show)
    print(head)
    option_select=int(input("menu(5 for exit ):"))
    #all menu functions   

    #billing of your orders
    def logic_of_bill():
        cur.execute("select b_name,b_price from bill_list ")
        bill_data=cur.fetchall()
        head_bill=PrettyTable(['Order','Price'])
        head_bill.add_rows(bill_data)
        print(head_bill)
    def bill():  
        logic_of_bill() 
        print('1:for total \n2:for delete bill \n3:for exit pogramm \n4:exit menu')
        bill_input=int(input(":"))
        if bill_input==1:
            cur.execute("select sum(b_price) from bill_list ")
            bill_data=cur.fetchall()
            head_bill=PrettyTable(['total_price'])
            head_bill.add_rows(bill_data)
            print(head_bill)
            bill()
        elif bill_input==2:
            cur.execute("delete from bill_list")
            mydb.commit()
            bill_data=cur.fetchall()
            print(bill_data)  
            bill()  
        elif bill_input==3:
            exit()   
        elif bill_input==4:
            main_list()    
        else:
            print("invalid option")
            bill()        


    #dessert menu     
    def dessert():
        cur.execute("select * from dessert_list")
        dessert_data=cur.fetchall()
        head_dessert=PrettyTable(['d_id','d_name','d_price'])
        head_dessert.add_rows(dessert_data)
        print(head_dessert)
        dessert_input=int(input("select your order(6 for returning menu):"))
        if dessert_input==6:
            main_list()
        elif dessert_input>6:
            print("error")
            dessert()   

        cur.execute(f'insert into bill_list(b_name,b_price) select d_name,d_price from dessert_list where d_id ="{dessert_input}"')
        mydb.commit()
       
        logic_of_bill()
        dessert()
    def meals():
        cur.execute("select * from meals_list")
        meals_data=cur.fetchall()
        head_meals=PrettyTable(['m_id','m_name','m_price'])
        head_meals.add_rows(meals_data)
        print(head_meals)
        meals_input=int(input("select your order(11 for  returning menu):"))
        if meals_input==11:
            main_list()
        elif meals_input>11:
            print("error")
            meals() 

        cur.execute(f'insert into bill_list(b_name,b_price) select m_name,m_price from meals_list where m_id ="{meals_input}"')
        mydb.commit()
        logic_of_bill()
        meals()
    def snacks():
        cur.execute("select * from snacks_list")
        snacks_data=cur.fetchall()
        head_snacks=PrettyTable(['s_id','s_name','s_price'])
        head_snacks.add_rows(snacks_data)
        print(head_snacks)
        snacks_input=int(input("select your order(8 for returing menu):"))
        if snacks_input==8:
            main_list()
        elif snacks_input>8:
            print("error")
            snacks()    

        cur.execute(f'insert into bill_list(b_name,b_price) select s_name,s_price from snacks_list where s_id ="{snacks_input}"')
        mydb.commit()
        logic_of_bill()
        snacks()

    #logic part for selecting tables
    if option_select==1:
        bill()
    elif option_select==2:
        dessert()
    elif option_select==3:
        meals()
    elif option_select==4:
        snacks()     
    elif option_select==5:
        exit()    
    else:
        print("invalid option try again")   
        main_list() 
        
main_list()    


