import mysql.connector as p
mydb=p.connect(host="localhost",user="root",password="Nancymomoland3000@")
cur=mydb.cursor()
l=['create database cafe_menu_list','use cafe_menu_list','create table snacks_list(s_id int(10),s_name varchar(30),s_price int(10))','create table meals_list(m_id int(10),m_name varchar(30),m_price int(10))','create table dessert_list(d_id int(10),d_name varchar(30),d_price int(10))','create table bill_list(b_name varchar(30),b_price int)','insert into meals_list values(1,"Chicken Biriyani",120)',
'insert into meals_list values(2,"Mutton Biriyani",180)',
'insert into meals_list values(3,"Veg Biriyani",60)',
'insert into meals_list values(4,"Lemon Rice",30)',
'insert into meals_list values(5,"Fried Rice",100)',
'insert into meals_list values(6," Mixed Fried Rice",150)',
'insert into meals_list values(7,"Chicken Tikka Masala",140)',
'insert into meals_list values(8,"Butter Tikka Masala",130)',
'insert into meals_list values(9,"panner Tikka Masala",90)',
'insert into meals_list values(10,"Butter Chicken Masala",170)',
'insert into snacks_list values(1,"Chicken Pakora(6 pcs)",70)',
'insert into snacks_list values(2,"Veg Pakora(6 pcs)",30)',
'insert into snacks_list values(3,"Paneer Pakora(6 pcs)",60)',
'insert into snacks_list values(4,"Chilli Paneer(6 pcs)",120)',
'insert into snacks_list values(5,"Chicken Momo(6 pcs)",60)',
'insert into snacks_list values(6,"Veg Momo(6 pcs)",50)',
'insert into snacks_list values(7,"Paneer Momo(6 pcs)",40)',
'insert into dessert_list values(1,"cakes",200)',
'insert into dessert_list values(2,"custard",150)',
'insert into dessert_list values(3,"pastries",40)',
'insert into dessert_list values(4,"puddings",90)',
'insert into dessert_list values(5,"appine wine",780)'
]
for i in range(len(l)):
    cur.execute(f'{l[i]}')
    mydb.commit()
    cur.fetchall()
    print(cur)

